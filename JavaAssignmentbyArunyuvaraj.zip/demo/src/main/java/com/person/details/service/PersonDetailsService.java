package com.person.details.service;

import com.person.details.dto.PersonCreateResponse;
import com.person.details.dto.PersonDetailsRequest;
import com.person.details.dto.PersonSearchRequest;

public interface PersonDetailsService {

	PersonCreateResponse addPersonDetails(PersonDetailsRequest personDetailsInput);

	PersonCreateResponse getPerson(PersonSearchRequest searchRequest);

}
