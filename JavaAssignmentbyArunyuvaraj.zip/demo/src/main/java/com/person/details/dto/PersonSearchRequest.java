package com.person.details.dto;

public class PersonSearchRequest {
	
	public String name;
	
	public String salary;
	
	public String pension;
	
	public String address;
	
	public String phoneNumber;


}
