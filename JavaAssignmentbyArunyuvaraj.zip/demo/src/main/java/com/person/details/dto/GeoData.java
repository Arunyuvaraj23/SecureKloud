package com.person.details.dto;

public class GeoData {

	public String name;
	public String address;
	public String phoneNumber;
	
}
