package com.person.details.dto;

public class PersonDetailsRequest {

	public String geoDataFilePath;
	
	public String salaryDataFilePath;
	
	
	
}
