package com.person.details.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PersonEntity {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long id;
	
	@Column(columnDefinition="VARCHAR2(100) NULL")
	public String name;

	@Column(columnDefinition="VARCHAR2(100) NULL")
	public String salary;
	
	@Column(columnDefinition="VARCHAR2(100) NULL")
	public String pension;
	
	@Column(columnDefinition="VARCHAR2(100) NULL")
	public String address;
	
	@Column(columnDefinition="VARCHAR2(100) NULL")
	public String phoneNumber;
	
}
