package com.person.details.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.person.details.dto.GeoData;
import com.person.details.dto.PersonCreateResponse;
import com.person.details.dto.PersonDetailsRequest;
import com.person.details.dto.PersonSearchRequest;
import com.person.details.entity.PersonEntity;
import com.person.details.repo.PersonRepository;
import com.person.details.dto.PersonData;
import com.person.details.service.PersonDetailsService;

@Service
public class PersonDetailsServiceImpl implements PersonDetailsService {

	@Autowired
	PersonRepository personRepo;
	
	@Override
	public PersonCreateResponse addPersonDetails(PersonDetailsRequest personDetailsInput) {
	
		Map<String,GeoData> geoDatas = buildGeoData(personDetailsInput.geoDataFilePath);
		List<PersonData> salaryDatas = buildSalaryData(personDetailsInput.salaryDataFilePath,geoDatas);
		
		PersonCreateResponse personCreateResponse = new PersonCreateResponse();
		personCreateResponse.personDatas = salaryDatas;
		
		List<PersonEntity> entities = new ArrayList<>();
		
		salaryDatas.forEach(per->{
			PersonEntity entity = new PersonEntity();
			entity.address = per.address;
			entity.name = per.name;
			entity.pension = per.pension;
			entity.salary = per.salary;
			entity.phoneNumber = per.phoneNumber;

			entities.add(entity);
		});
		
		personRepo.saveAll(entities);
		
		return personCreateResponse;
	}

	private Map<String,GeoData> buildGeoData(String fileName) {
		Map<String,GeoData> geoDatas = new HashMap<>();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

			DocumentBuilder db = dbf.newDocumentBuilder();

			Document doc = db.parse(new File(fileName));

			doc.getDocumentElement().normalize();

			NodeList list = doc.getElementsByTagName("person");

			for (int temp = 0; temp < list.getLength(); temp++) {

				Node node = list.item(temp);

				if (node.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) node;
					GeoData geoData = new GeoData();

					geoData.name = element.getAttribute("name");

					geoData.address = element.getElementsByTagName("address").item(0).getTextContent();
					geoData.phoneNumber = element.getElementsByTagName("phonenumber").item(0).getTextContent();

					geoDatas.put(geoData.name, geoData);
				}
			}

		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		return geoDatas;

	}

	private List<PersonData> buildSalaryData(String fileName,Map<String,GeoData> geoDatas) {
		List<PersonData> personDatas = new ArrayList<>();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

			DocumentBuilder db = dbf.newDocumentBuilder();

			Document doc = db.parse(new File(fileName));

			doc.getDocumentElement().normalize();

			NodeList list = doc.getElementsByTagName("person");

			for (int temp = 0; temp < list.getLength(); temp++) {

				Node node = list.item(temp);

				if (node.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) node;
					PersonData salaryData = new PersonData();

					salaryData.name = element.getAttribute("name");

					salaryData.salary = element.getElementsByTagName("salary").item(0).getTextContent();
					salaryData.pension = element.getElementsByTagName("pension").item(0).getTextContent();
					salaryData.address = geoDatas.get(salaryData.name).address;
					salaryData.phoneNumber = geoDatas.get(salaryData.name).phoneNumber;
					
					
					personDatas.add(salaryData);

				}
			}

		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		return personDatas;

	}

	@Override
	public PersonCreateResponse getPerson(PersonSearchRequest searchKey) {

		PersonEntity personEntity = new PersonEntity();
		personEntity.address = searchKey.address;
		personEntity.name = searchKey.name;
		personEntity.pension = searchKey.pension;
		personEntity.salary = searchKey.salary;
		personEntity.phoneNumber = searchKey.phoneNumber;
	
		
		List<PersonEntity> personEntities = personRepo.findAll(Example.of(personEntity));
		
		List<PersonData> personDatas = new ArrayList<>();
		
		personEntities.forEach(person->{
			PersonData personData = new PersonData();
			personData.address = person.address;
			personData.name = person.name;
			personData.pension = person.pension;
			personData.salary = person.salary;
			personData.phoneNumber = person.phoneNumber;
			personDatas.add(personData);
		});
		
		PersonCreateResponse personCreateResponse = new PersonCreateResponse();
		personCreateResponse.personDatas = personDatas;
		
		return personCreateResponse;
	}

}
