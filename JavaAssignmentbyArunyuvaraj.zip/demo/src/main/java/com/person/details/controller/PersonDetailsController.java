package com.person.details.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.person.details.dto.PersonCreateResponse;
import com.person.details.dto.PersonDetailsRequest;
import com.person.details.dto.PersonSearchRequest;
import com.person.details.service.PersonDetailsService;

@RestController
@RequestMapping("/person/v1")
public class PersonDetailsController {

	@Autowired
	private PersonDetailsService personDetailsService;

	@PostMapping
	public ResponseEntity<PersonCreateResponse> addPersonDetails(@RequestBody PersonDetailsRequest personDetailsInput) {
		PersonCreateResponse personCreateResponse = personDetailsService.addPersonDetails(personDetailsInput);
		return new ResponseEntity<PersonCreateResponse>(personCreateResponse, HttpStatus.CREATED);

	}
	
	@PostMapping("/search")
	public ResponseEntity<PersonCreateResponse> getPersonDetails(@RequestBody PersonSearchRequest searchRequest ){
		PersonCreateResponse personCreateResponse = personDetailsService.getPerson(searchRequest);
		return new ResponseEntity<PersonCreateResponse>(personCreateResponse, HttpStatus.OK);
	
	}

}
