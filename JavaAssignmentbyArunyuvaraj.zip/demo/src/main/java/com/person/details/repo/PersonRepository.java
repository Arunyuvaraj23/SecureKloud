package com.person.details.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.person.details.entity.PersonEntity;

public interface PersonRepository extends JpaRepository<PersonEntity, Long>{

	
}
