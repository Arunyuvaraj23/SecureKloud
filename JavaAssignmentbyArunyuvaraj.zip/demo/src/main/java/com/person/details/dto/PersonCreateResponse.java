package com.person.details.dto;

import java.util.List;

public class PersonCreateResponse {

	public List<PersonData> personDatas;
}
